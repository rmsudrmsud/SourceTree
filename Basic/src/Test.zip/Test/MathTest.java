package Test;


public class MathTest {



	public static void main(String[] args) {

		// TODO Auto-generated method stub

		System.out.println("pi:"+Math.PI);

		System.out.println("E:"+Math.E);

		System.out.println("Math.abs(-1)"+Math.abs(-1)); //절대값

		System.out.println("Math.sin(30):"+Math.sin(30));

	}



}