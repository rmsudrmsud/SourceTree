package PocketMon2;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Picachu p = new Picachu();
		p.eat();
		p.sleap();
		p.play();
		p.exc();
		p.printInfo();
	}

}
