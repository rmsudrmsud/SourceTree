package abstract_test;

public class DaoImplOracle implements Dao {

	@Override
	public void insert() {
		// TODO Auto-generated method stub
		System.out.println("Oracle insert");
	}

	@Override
	public void select() {
		// TODO Auto-generated method stub
		System.out.println("Oracle select");
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		System.out.println("Oracle update");
	}

	@Override
	public void delete() {
		// TODO Auto-generated method stub
		System.out.println("Oracle delete");
	}

}
