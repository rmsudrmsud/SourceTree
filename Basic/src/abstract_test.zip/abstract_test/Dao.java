package abstract_test;
//db작업.
public interface Dao {
	void insert();
	
	void select();
	
	void update();
	
	void delete();
	
}
