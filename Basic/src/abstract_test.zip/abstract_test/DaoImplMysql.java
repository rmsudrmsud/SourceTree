package abstract_test;

public class DaoImplMysql implements Dao {

	@Override
	public void insert() {
		// TODO Auto-generated method stub
		System.out.println("Mysql insert");
	}

	@Override
	public void select() {
		// TODO Auto-generated method stub
		System.out.println("Mysql select");
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		System.out.println("Mysql update");
	}

	@Override
	public void delete() {
		// TODO Auto-generated method stub
		System.out.println("Mysql delete");
	}

}
